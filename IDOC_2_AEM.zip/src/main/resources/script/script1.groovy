import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.pd.PartnerDirectoryService
import com.sap.it.api.ITApiFactory

def Message processData(Message message) {

    // --------------------------------------------------
    // Partner Directory Service
    // --------------------------------------------------
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null)
    if (service == null) {
        return message
    }

    // --------------------------------------------------
    // 1. Read required IDoc headers
    // --------------------------------------------------
    def headers = message.getHeaders()

    def mestyp  = headers.get("SAP_IDoc_EDIDC_MESTYP")
    def idoctyp = headers.get("SAP_IDoc_EDIDC_IDOCTYP")
    def cimtyp  = headers.get("SAP_IDoc_EDIDC_CIMTYP")

    if (!mestyp || !idoctyp) {
        return message
    }

    // --------------------------------------------------
    // 2. Build PartnerID
    // --------------------------------------------------
    def partnerID = (cimtyp && cimtyp.toString().trim())
            ? "${mestyp}.${idoctyp}.${cimtyp}"
            : "${mestyp}.${idoctyp}"

    // --------------------------------------------------
    // 3. Read XPath parameters from Partner Directory
    // --------------------------------------------------
    def XPath1 = service.getParameter("XPath1", partnerID, String.class)
    def XPath2 = service.getParameter("XPath2", partnerID, String.class)
    def XPath3 = service.getParameter("XPath3", partnerID, String.class)

    // --------------------------------------------------
    // 4. Set headers (null-safe)
    // --------------------------------------------------
    if (XPath1) message.setHeader("XPath1", XPath1)
    if (XPath2) message.setHeader("XPath2", XPath2)
    if (XPath3) message.setHeader("XPath3", XPath3)

    return message
}
