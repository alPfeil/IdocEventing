import com.sap.gateway.ip.core.customdev.util.Message

import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.xpath.XPathFactory
import javax.xml.XMLConstants
import org.xml.sax.InputSource
import java.io.StringReader

def Message processData(Message message) {

    def headers = message.getHeaders()

    // --------------------------------------------------
    // Read XPath headers
    // --------------------------------------------------
    def xpathMap = [
        XPath1: headers.get("XPath1"),
        XPath2: headers.get("XPath2"),
        XPath3: headers.get("XPath3")
    ]

    // If no XPath is defined → exit silently
    if (xpathMap.values().every { !it || !it.toString().trim() }) {
        return message
    }

    // --------------------------------------------------
    // Read Topic header
    // --------------------------------------------------
    def topic = headers.get("Topic") ?: ""

    // --------------------------------------------------
    // Read payload
    // --------------------------------------------------
    def body = message.getBody(String)
    if (!body || !body.trim()) {
        return message
    }

    // --------------------------------------------------
    // Secure XML parsing (XXE-safe)
    // --------------------------------------------------
    def dbf = DocumentBuilderFactory.newInstance()
    dbf.setNamespaceAware(true)

    dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
    dbf.setFeature("http://xml.org/sax/features/external-general-entities", false)
    dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false)
    dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
    dbf.setXIncludeAware(false)
    dbf.setExpandEntityReferences(false)
    dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true)

    def document
    try {
        document = dbf.newDocumentBuilder()
                      .parse(new InputSource(new StringReader(body)))
    } catch (Exception e) {
        return message
    }

    def xPath = XPathFactory.newInstance().newXPath()

    // --------------------------------------------------
    // Execute XPaths
    // --------------------------------------------------
    xpathMap.each { key, xp ->

        if (!xp || !xp.toString().trim()) {
            return
        }

        try {
            // Namespace-agnostic XPath
            def safeXPath = xp.toString().trim()
                    .split('/')
                    .findAll { it }
                    .collect { "*[local-name()='${it}']" }
                    .join('/')

            safeXPath = "/" + safeXPath

            def value = xPath.evaluate(safeXPath, document)

            if (value && value.trim()) {

                def trimmedValue = value.trim()

                // Set result header
                message.setHeader("${key}Result", trimmedValue)

                // Append to Topic
                topic = (topic == "" || topic.endsWith("/"))
                        ? "${topic}${trimmedValue}"
                        : "${topic}/${trimmedValue}"
            }
        } catch (Exception ignored) {
            // silent by design
        }
    }

    // --------------------------------------------------
    // Write back Topic header
    // --------------------------------------------------
    message.setHeader("Topic", topic)

    return message
}
